*****************

Pour compiler�:
modifier le Makefile.bat et mettre le chemin de pure data

commannde�: Makefile.bat fichier (sans extension)

lancer shaping.pd 

A droite, appuyer sur bang pour que des notes soient g�n�rer al�atoirement sur un tempo r�gler dans l'objet metro.
Pour jouer manuellement, appuyer sur stop, et cliquer sur les diff�rentees fr�quence en dessous le select, chacune correspondant a une note.

******************
